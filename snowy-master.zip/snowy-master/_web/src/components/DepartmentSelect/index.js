import DepartmentSelect from './DepartmentSelect'

export default DepartmentSelect
