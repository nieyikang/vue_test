sys_area.sql: https://pan.xiaonuo.vip/#s/65K_IzOw

sys_area_kingbase8_r3.dmp: https://pan.xiaonuo.vip/#s/65K_UJFQ

sys_area_mssql.sql: https://pan.xiaonuo.vip/#s/65K_gwMA

sys_area_oracle.sql: https://pan.xiaonuo.vip/#s/65K_nkaQ

sys_area_postgresql.sql: https://pan.xiaonuo.vip/#s/65K_vyrg